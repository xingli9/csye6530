/**
 * 
 */
package org.foobar.iot.module7;

import java.util.logging.Logger;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.server.resources.CoapExchange;

/**
 * @author xingli
 *
 */
public class ResourceHumidity extends CoapResource {
	private static final Logger _Logger = 
			Logger.getLogger(ResourceHumidity.class.getName());
	//static
	
	//constructors

	/**
	 * @param name
	 */
	public ResourceHumidity(String name) {
		super(name);
	}

	/**
	 * @param name
	 * @param visible
	 */
	public ResourceHumidity(String name, boolean visible) {
		super(name, visible);
	}
	
	//public methods
	
	@Override
	public void handleGET(CoapExchange ce) {
		
		String responseMsg =  "here is my response to humidity request:" + super.getName();
		
		ce.respond(ResponseCode.VALID, responseMsg);
		
		_Logger.info("Handling GET:" + responseMsg);
		_Logger.info(ce.getRequestCode().toString() + ": " + ce.getRequestText());
	}
	

}
