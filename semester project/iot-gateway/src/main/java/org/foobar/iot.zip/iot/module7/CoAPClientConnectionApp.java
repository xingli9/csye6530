/**
 * 
 */
package org.foobar.iot.module7;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author xingli
 *
 */
public class CoAPClientConnectionApp {
	
	private static final Logger _Logger = 
			Logger.getLogger(CoAPClientConnectionApp.class.getName());
	
	private static CoAPClientConnectionApp _App = null;
	
	public CoAPClientConnectionApp() {
		super();
		//caapClient = new CoAPClient();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			_App = new CoAPClientConnectionApp();
			_App.start();
		} catch (Exception e) {
			_Logger.log(Level.SEVERE, "Bad staff ", e);
			e.printStackTrace();
			System.exit(1);
		}

	}

	//public methods
	
	public void start() {
		CoAPClientConnection clientConn = new CoAPClientConnection();
		clientConn.runTests("temp");
		clientConn.sendGetRequest();
		
	}
	
	
	//private CoAPCommClient = new CoAPClientConnection()
	
	

}
