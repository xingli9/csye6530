/**
 * 
 */
package org.foobar.iot.module7;

import java.util.logging.Logger;

import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.CoapServer;
import org.eclipse.californium.core.network.Endpoint;
import org.foobar.iot.common.ConfigConst;

/**
 * @author xingli
 *
 */
public class CoAPServerConnection {

	private static final Logger _Logger = 
			Logger.getLogger(CoAPServerConnection.class.getName());
	
	private CoapServer _coapServer;

	//static
	
	// private var's
	private String _protocol;
	private String _host;
	private int _port;
	private CoapClient _clientConn;
	private String _serverAddr;
//	private void initServer(String ...resourceNames) {
//		_coapServer = new CoapServer();
//		
//		if (_useMqtt) {
//			_mqttClient = new 
//		}	
//	}
	
	public CoAPServerConnection() {
		this(ConfigConst.DEFAULT_COAP_SERVER);
	}
	
	public CoAPServerConnection(String host) {
		super();
		
		_protocol = ConfigConst.DEFAULT_COAP_PROTOCOL;
		_port = ConfigConst.DEFAULT_COAP_PORT;
		
		if (host != null && host.trim().length() > 0) {
			_host = host;

		} else {
			_host = ConfigConst.DEFAULT_COAP_SERVER;

		}
		
		//Endpoint _serverAddr = _protocol + "://" + _host + ":" + _port;
		
		
		System.out.println("in coap constructor");
		_coapServer = new CoapServer();
		//_coapServer.addEndpoint(endpoint);
		
		ResourceTemp resourceTemp = new ResourceTemp("temp");
		ResourceHumidity resourceHumidity = new ResourceHumidity("humidity");
		
		addResource(resourceTemp);
		addResource(resourceHumidity);
	}
	
//	public CoAPServerConnection(String ...resourceNames) {
//		
//	}
	//public methods
	public void addDefaultResource(String Name) {
		
	}
	public void addResource(CoapResource resource) {
		if (resource != null) {
			if (_coapServer != null) {
				
				_coapServer.add(resource);
			}
		}
	}
	public void start() {
		System.out.println("in coap start");
		if (_coapServer == null) {
			System.out.println("in coap, coapserver is null");

			_Logger.info("Creating CoAP server instance and 'temp' handler...");
			_coapServer = new CoapServer();
			// NOTE: you must implement TestResourceHandler yourself
			ResourceTemp tempHandler = new ResourceTemp("temp");
			_coapServer.add(tempHandler);
		}
		_Logger.info("Starting CoAP server...");
		_coapServer.start();
		System.out.println("coap endpoint :  ---" + _coapServer.getEndpoint(5683).getAddress());
	}
	
	public void stop() {
		_coapServer.stop();
	}
}
