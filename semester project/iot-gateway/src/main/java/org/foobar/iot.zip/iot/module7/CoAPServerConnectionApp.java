/**
 * 
 */
package org.foobar.iot.module7;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author xingli
 *
 */
public class CoAPServerConnectionApp {
	
	private static final Logger _Logger = 
			Logger.getLogger(CoAPServerConnectionApp.class.getName());
	
	private static CoAPServerConnectionApp _App = null;
	
	public CoAPServerConnectionApp() {
		super();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			_App = new CoAPServerConnectionApp();
			_App.start();
		} catch (Exception e) {
			_Logger.log(Level.SEVERE, "Bad staff ", e);
			System.exit(1);
		}

	}

	//public methods
	
	public void start() {
		System.out.println("in app start");
		CoAPServerConnection serverConn = new CoAPServerConnection();
		serverConn.start();
		
	}
}
