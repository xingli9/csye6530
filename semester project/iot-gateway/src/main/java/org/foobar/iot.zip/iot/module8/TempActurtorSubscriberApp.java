package org.foobar.iot.module8;

import java.util.logging.Logger;

import org.foobar.iot.module8.MqttClientConnector;

public class TempActurtorSubscriberApp {
	
	private String _userName = "A1E-JcZiIPWIb6oLtP4y7aMHY7Y0fOS6au";
	private String _authToken = null;
	private String _pemFileName = "/Users/xingli/Desktop/neu/class/2018fall/CSYE6530connectDevices/lecture/lecture8/industrial.pem";
	private String _host = "things.ubidots.com";

	
	// static
	private static final Logger _Logger = Logger.getLogger(TempActurtorSubscriberApp.class.getName());
	private static TempActurtorSubscriberApp _App;
	
	// params
	private MqttClientConnector _mqttClient;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		_App = new TempActurtorSubscriberApp();
		try {
			_App.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// constructors
	/**
	 * Default.
	 */

	public TempActurtorSubscriberApp() {
		super();
	}
	
	// public methods
	/**
	 * Connect to the MQTT client, then: 1) If this is the subscribe app, subscribe
	 * to the given topic 2) If this is the publish app, publish a test message to
	 * the given topic
	 */
	public void start() {
		_mqttClient = new MqttClientConnector(_host, _userName, _pemFileName, _authToken);
		_mqttClient.connect();
		String topicName = "/v1.6/devices/homeiotgateway/tempacurator";
		// only for subscribing...
		_mqttClient.subscribeToTopic(topicName); 
		//_mqttClient.subscribeToAll(); 
		//_mqttClient.disconnect();
	}
	
	
	

}
