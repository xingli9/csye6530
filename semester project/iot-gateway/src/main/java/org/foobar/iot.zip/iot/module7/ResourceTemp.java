/**
 * 
 */
package org.foobar.iot.module7;

import java.util.logging.Logger;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.server.resources.CoapExchange;

/**
 * @author xingli
 *
 */
public class ResourceTemp extends CoapResource {
	//static
	private static final Logger _Logger = 
			Logger.getLogger(ResourceTemp.class.getName());
	
	//constructors
	
	public ResourceTemp() {
		super("default");
	}

	/**
	 * @param name
	 */
	public ResourceTemp(String name) {
		super(name);
		System.out.println("in temp constructor");
	}

	/**
	 * @param name
	 * @param visible
	 */
	public ResourceTemp(String name, boolean visible) {
		super(name, visible);
	}
	
	//public methods
	
	@Override
	public void handleGET(CoapExchange ce) {
		
		String responseMsg =  "here is my response to:" + super.getName();
		//read temp from file, and return to client
//		File file = new File("fiel");
//		FileinputStream fis = null;
//		fis = new FileInputSteam(file);
//		int bytes  = fie.available();
//		byte[] data = new byte[bytes];
//		int count = fie.read(data);
//		
//		for (int i = 0; i < bytes; i++) {
//			
//		}
		ce.respond(ResponseCode.VALID, responseMsg);
		
		_Logger.info("Handling GET:" + responseMsg);
		_Logger.info(ce.getRequestCode().toString() + ": " + ce.getRequestText());
	}
	
	@Override
	public void handlePOST(CoapExchange exchange) {
		String responseMsg =  "here is my response to:" + super.getName();

		System.out.println(exchange.getRequestText());
		exchange.respond(ResponseCode.VALID, responseMsg);
		
		_Logger.info("Handling POST:" + responseMsg);
		_Logger.info(exchange.getRequestCode().toString() + ": " + exchange.getRequestText());
	}
	
	@Override
	public void handlePUT(CoapExchange exchange) {
		String responseMsg =  "here is my response to:" + super.getName();
		
		exchange.respond(ResponseCode.VALID, responseMsg);
		
		_Logger.info("Handling PUT:" + responseMsg);
		_Logger.info(exchange.getRequestCode().toString() + ": " + exchange.getRequestText());
	}
	
	@Override
	public void handleDELETE(CoapExchange exchange) {
		String responseMsg =  "here is my response to:" + super.getName();
		
		exchange.respond(ResponseCode.VALID, responseMsg);
		
		_Logger.info("Handling DELETE:" + responseMsg);
		_Logger.info(exchange.getRequestCode().toString() + ": " + exchange.getRequestText());
	}
	
	

}
