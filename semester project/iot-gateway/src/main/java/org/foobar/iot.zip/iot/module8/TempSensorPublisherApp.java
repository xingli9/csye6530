/**
 * 
 */
package org.foobar.iot.module8;

import java.util.logging.Logger;
import org.foobar.iot.module8.MqttClientConnector;


/**
 * @author xingli
 *
 */
public class TempSensorPublisherApp {
	
	private String _userName = "A1E-JcZiIPWIb6oLtP4y7aMHY7Y0fOS6au";
	private String _authToken = null;
	private String _pemFileName = "/Users/xingli/Desktop/neu/class/2018fall/CSYE6530connectDevices/lecture/lecture8/industrial.pem";
	private String _host = "things.ubidots.com";
	
	// static
	private static final Logger _Logger = Logger.getLogger(TempSensorPublisherApp.class.getName());
	private static TempSensorPublisherApp _App;
	
	// params
	private MqttClientConnector _mqttClient;
	
	/**
	 * 
	 */
	public TempSensorPublisherApp() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		_App = new TempSensorPublisherApp();
		try {
			_App.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//things.ubidots.com
	public void start() {
		//_mqttClient = new MqttClientConnector(configconst.DEFAULT_UBIDOTS_SERVER, "{user test roken}", "user/..../ubidots_cert.pem");
		_mqttClient = new MqttClientConnector(_host, _userName, _pemFileName, _authToken);
		_mqttClient.connect();
		String topicName = "/v1.6/devices/HomeIotGateway/tempsensor";
		
		// only for publishing...
		String payload = "2";
		// only for publishing...
		_mqttClient.publishMessage(topicName, 0, payload.getBytes());
		_mqttClient.disconnect();
	}
}